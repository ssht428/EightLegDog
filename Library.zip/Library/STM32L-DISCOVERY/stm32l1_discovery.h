 /**
  ******************************************************************************
  * @file    stm32l1_discovery.h
  * @author  Microcontroller Division
  * @version V1.0.2
  * @date    September-2020
  * @brief   Input/Output defines
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  */

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __STM32L1_DISCOVERY_H
#define __STM32L1_DISCOVERY_H

/* Includes ------------------------------------------------------------------*/
#include "stm32l1xx.h"  

#define bool      _Bool
#define FALSE     0
#define TRUE      !FALSE

/** @addtogroup Utilities
  * @{
  */
  
/** @addtogroup STM32L1_DISCOVERY
  * @{
  */
      
/** @addtogroup STM32L1_DISCOVERY_LOW_LEVEL
  * @{
  */ 

/** @defgroup STM32L1_DISCOVERY_LOW_LEVEL_Exported_Types
  * @{
  */
typedef enum 
{
  LED3 = 0,
  LED4 = 1,
} Led_TypeDef;

typedef enum 
{  
  BUTTON_USER = 0,
} Button_TypeDef;

typedef enum 
{  
  BUTTON_MODE_GPIO = 0,
  BUTTON_MODE_EXTI = 1
} ButtonMode_TypeDef;     
/**
  * @}
  */ 

/** @defgroup STM32L1_DISCOVERY_LOW_LEVEL_Exported_Constants
  * @{
  */ 


  /* MACROs for SET, RESET or TOGGLE Output port */

#define STM_EVAL_GPIO_HIGH(a,b) 		    a->BSRRL = b
#define STM_EVAL_GPIO_LOW(a,b)		      a->BSRRH = b
#define STM_EVAL_GPIO_TOGGLE(a,b) 	    a->ODR ^= b 

#define CTN_GPIO_PORT                   GPIOC
#define CTN_CNTEN_GPIO_PIN              GPIO_Pin_13
#define CTN_GPIO_CLK                    RCC_AHBPeriph_GPIOC

#define WAKEUP_GPIO_PORT                GPIOA

#define IDD_MEASURE_PORT	              GPIOA
#define IDD_MEASURE                     GPIO_Pin_4

/** @addtogroup STM32L1_DISCOVERY_LOW_LEVEL_LED
  * @{
  */
#define LEDn                             2

#define LED3_PIN                         GPIO_Pin_7               // Green Led
#define LED3_GPIO_PORT                   GPIOB
#define LED3_GPIO_CLK                    RCC_AHBPeriph_GPIOB 

#define LED4_PIN                         GPIO_Pin_6               // Blue Led
#define LED4_GPIO_PORT                   GPIOB
#define LED4_GPIO_CLK                    RCC_AHBPeriph_GPIOB 
/**
  * @}
  */ 
  
/** @addtogroup STM32F3_DISCOVERY_LOW_LEVEL_BUTTON
  * @{
  */  
#define BUTTONn                          1  

/**
 * @brief Wakeup push-button
 */
#define USER_BUTTON_PIN                GPIO_Pin_0
#define USER_BUTTON_GPIO_PORT          GPIOA
#define USER_BUTTON_GPIO_CLK           RCC_AHBPeriph_GPIOA
#define USER_BUTTON_EXTI_LINE          EXTI_Line0
#define USER_BUTTON_EXTI_PORT_SOURCE   EXTI_PortSourceGPIOA
#define USER_BUTTON_EXTI_PIN_SOURCE    EXTI_PinSource0
#define USER_BUTTON_EXTI_IRQn          EXTI0_IRQn 
/**
  * @}
  */ 
  
/** @defgroup STM32L1_DISCOVERY_LOW_LEVEL_Exported_Macros
  * @{
  */  
/**
  * @}
  */ 


/** @defgroup STM32L1_DISCOVERY_LOW_LEVEL_Exported_Functions
  * @{
  */
void STM_EVAL_LEDInit(Led_TypeDef Led);
void STM_EVAL_LEDOn(Led_TypeDef Led);
void STM_EVAL_LEDOff(Led_TypeDef Led);
void STM_EVAL_LEDToggle(Led_TypeDef Led);
void STM_EVAL_PBInit(Button_TypeDef Button, ButtonMode_TypeDef Button_Mode);
uint32_t STM_EVAL_PBGetState(Button_TypeDef Button);
/**
  * @}
  */
  




#endif


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

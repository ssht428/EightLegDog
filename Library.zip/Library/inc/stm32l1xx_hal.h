/**
  ******************************************************************************
  * @file    stm32L1xx_hal.h
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    19-June-2016
  * @brief   This file contains all the functions prototypes for the HAL 
  *          module driver.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32L1xx_HAL_H
#define __STM32L1xx_HAL_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "STM32l1xx.h"

/** @addtogroup STM32L1xx_HAL_Driver
  * @{
  */

/** @addtogroup HAL
  * @{
  */ 

/* Exported types ------------------------------------------------------------*/
/** @defgroup HAL_TICK_FREQ Tick Frequency
  * @{
  */
typedef enum
{
  HAL_TICK_FREQ_10HZ         = 100U,
  HAL_TICK_FREQ_100HZ        = 10U,
  HAL_TICK_FREQ_1KHZ         = 1U,
  HAL_TICK_FREQ_DEFAULT      = HAL_TICK_FREQ_1KHZ
} HAL_TickFreqTypeDef;

/** 
  * @brief  HAL Status structures definition  
  */  
typedef enum 
{
  HAL_OK       = 0x00,
  HAL_ERROR    = 0x01,
  HAL_BUSY     = 0x02,
  HAL_TIMEOUT  = 0x03
} HAL_StatusTypeDef;
  /** @defgroup SYSCFG_Exported_Constants SYSCFG Exported Constants
    * @{
    */
  
  /** @defgroup SYSCFG_Constants SYSCFG: SYStem ConFiG
    * @{
    */
  
  /** @defgroup SYSCFG_BootMode Boot Mode
    * @{
    */
  
#define SYSCFG_BOOT_MAINFLASH          (0x00000000U)
#define SYSCFG_BOOT_SYSTEMFLASH        ((uint32_t)SYSCFG_MEMRMP_BOOT_MODE_0)
#if defined(FSMC_R_BASE)
#define SYSCFG_BOOT_FSMC               ((uint32_t)SYSCFG_MEMRMP_BOOT_MODE_1)
#endif /* FSMC_R_BASE  */
#define SYSCFG_BOOT_SRAM               ((uint32_t)SYSCFG_MEMRMP_BOOT_MODE)

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define  DVDD_VALUE                   ((uint32_t)3000) /*!< Value of VDD in mv */   
#define  SYSTICK_PRIORITY        			((uint32_t)0x02) /*!< Set systick interrupt to lowest priority */
#define  USE_RTOS                     0     
#define  PREFETCH_ENABLE              1
#define  HAL_MAX_DELAY      		      0xFFFFFFFFU
#define  UID_BASE                     0x1FFF7A10UL  


#define RCC_AHBPeriph_ALL              ((uint32_t)0x4B0090FF)
#define RCC_APB1Periph_ALL             ((uint32_t)0x00005A1D)
#define RCC_APB2Periph_ALL             ((uint32_t)0xB0FECA3F)

/* Exported variables --------------------------------------------------------*/
/** @defgroup HAL_Exported_Variables HAL Exported Variables
  * @{
  */
//extern __IO uint32_t uwTick;
//extern uint32_t uwTickPrio;
//extern uint32_t uwTickFreq;

/* Exported functions --------------------------------------------------------*/

/* Initialization and de-initialization functions  ******************************/
HAL_StatusTypeDef HAL_Init(void);
HAL_StatusTypeDef HAL_DeInit(void);
void HAL_MspInit(void);
void HAL_MspDeInit(void);
HAL_StatusTypeDef HAL_InitSystick(uint32_t SystickPriority);

/* Peripheral Control functions  ************************************************/
void HAL_IncTick(void);
void HAL_Delay(__IO uint32_t Delay);
uint32_t HAL_GetTick(void);
void HAL_SuspendTick(void);
void HAL_ResumeTick(void);
uint32_t HAL_GetHalVersion(void);



/**
  * @}
  */ 

/**
  * @}
  */ 
  
#ifdef __cplusplus
}
#endif

#endif /* __STM32F1xx_HAL_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
